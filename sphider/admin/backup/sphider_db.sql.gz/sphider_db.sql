# Table backup from Sphider
# Creation date: 11-Oct-2015 09:12
# Database: sphider_db
# MySQL Server version: 5.6.26

# Valid end of backup from Sphider backup
